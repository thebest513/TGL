# -*- coding: utf-8 -*-
"""
1. "Post" to Validate or deploy json.
2. "Folder" to get folder json from Control-M Server.
3. "Cal" to get calendar json(Control-M AAPI 9.20 onwards only) from Contorl-M Server.
4. "Report" to generate Control-M reports.
5. "Status" to search AJF job status and group by job output keywords.

Restrictions
    Control-M AAPI before 9.20.220 does not support CJK'
    Control-M calendar in json not available before Control-M AAPI 9.20.100
    Control-M calendar "type=RuleBasedCalendar" not supported before Control-M AAPI 9.20.250

"""
import requests
import json
import os.path
import argparse
import urllib3
import time
import datetime
import urllib.parse
import sys
    
pwdpath = os.path.abspath(os.getcwd())

def base_url(host, port):
    ctm_base_url = f'https://{host}:{port}/automation-api'
    return ctm_base_url

def login(u, p, base_url):
    '''Login to Control-M and save token in a file'''
    # get relative directory path of the current script.py
    
    jsond = {
      'username': f'{u}',
      'password': f'{p}'
    }
    
    r = requests.post(url= base_url + '/session/login',\
                  json=jsond,\
                  verify=False)
        
    token = ''
    if r.json().get('token'):
        token = r.json().get('token')
        version = r.json().get('version')
        # with open(tokenf, 'w') as f:
            # f.write(token)
        # with open(versionf, 'w') as f:
            # f.write(version)
        print(f'Control-M api version: {version}')
        return token
    else:
        print(json.dumps(r.json(),indent=4,separators=(',',':'),ensure_ascii=False))
        sys.exit()
        
def get_server(base_url, token):
    '''Yields Contorl-M/Server name(s)'''
    CTM_headers = {
        'Authorization':f'Bearer {token}',
        }
    
    # api response is a list of Control-M/Servers info
    r = requests.get(url= base_url + '/config/servers/',\
                  headers = CTM_headers,\
                  verify=False)
    
    for server in r.json():
        yield server.get('name')

def get_newday(ctm, base_url, token):
    '''Get Contorl-M Newday time'''
    CTM_headers = {
        'Authorization':f'Bearer {token}',
        }
    
    # api response is a list of params and the values
    r = requests.get(url= base_url + f'/config/server/{ctm}/params',\
                  headers = CTM_headers,\
                  verify=False)
        
    for param in r.json():
        if param.get('name') == 'DAYTIME':
            # e.g. daytime = '+0700'
            return param.get('value')

def postj(j, service, base_url, token):
    '''build(validate) or deploy json to Contorl-M Server'''
    CTM_headers = {
        'Authorization':f'Bearer {token}',
        }
    
    # j = j.replace('\\','/')
    CTMfile = [
            ('definitionsFile', (j, open(j, 'rb'), 'application/json'))
    ]

    r = requests.post(url= base_url + f'/{service}',\
                  headers = CTM_headers,\
                  files = CTMfile,\
                  verify=False)

    jstr = json.dumps(r.json(),indent=4,separators=(',',':'),ensure_ascii=False)
    print(jstr) # Control-M error msg in json format
    return jstr

def get_folder(folder, base_url, token):
    '''GET folder definitions in json from Control-M Server'''
    if folder == '*':
        sys.exit('You cannot get all folder definition')
    CTM_headers = {
        'Authorization':f'Bearer {token}',
        }
    
    folder = urllib.parse.quote(folder)
    # param "server" is new in Control-M AAPI 9.20 and not compatible with Control-M AAPI 9.19
    # so use param "ctm" instead. I assume these 2 params are interchangible
    r = requests.get(url= base_url + f'/deploy/jobs?ctm=*&folder={folder}',\
                  headers = CTM_headers,\
                  verify=False)
        
    jstr = json.dumps(r.json(),indent=4,separators=(',',':'),ensure_ascii=False)
    # print(jstr)    
    if not r.json().get('errors'):
    #     if path:
    #         with open(path, 'w', encoding='UTF-8') as f:
    #             f.write(jstr)
    #     else: # if no output path specified
    #         print(jstr)
        return r.json()    
    else:
        print(jstr)
        with open(f'err_{folder}.json', 'w', encoding='UTF-8') as f:
            f.write(jstr)        

def get_cal(t, name, base_url, token):
    '''
    Control-M Calendar api services are only available from Control-M AAPI 9.20.100 onwards.
    "type=RuleBasedCalendar" not supported before Control-M AAPI 9.20.250.
    List calender names stored in Control-M or GET calender definitions in json from Control-M Server.
    
    response.status_code=200 even error or empty results
    '''
    CTM_headers = {
        'Authorization':f'Bearer {token}',
        }
    name = urllib.parse.quote(name)
    r = requests.get(url= base_url + f'/deploy/calendars?name={name}&type={t}',\
                  headers = CTM_headers,\
                  verify=False)
        
    jstr = json.dumps(r.json(),indent=4,separators=(',',':'),ensure_ascii=False)
    
    # r.json = {} if no calendars found
    if r.json(): # if response is not empty
        if not r.json().get('errors'):
            if name == urllib.parse.quote('*'):
                print(f'---{t} calenders stored in Control-M: ---')
                for k in r.json().keys():
                    print(k)
                return r.json().keys() # return dict_keys of calnames
            # elif path: # and if name=<valid calname>
            #     with open(path, 'w', encoding='UTF-8') as f:
            #         f.write(jstr)
            else: # if no output path specified
                print(jstr)
        else: # print error
            print(jstr)
    else: # response is not empty
        print('No calendar maching the search criteria')

def report(report, t, path, base_url, token):
    ''''Generate Control-M SHARED reports.
    Not supportive for report-templates created by yourself.
    '''
    CTM_headers = {
        'Authorization':f'Bearer {token}',
        }
    
    report = urllib.parse.quote(report)
    r = requests.get(url= base_url + f'/reporting/report/shared:{report}?format={t}',\
                  headers = CTM_headers,\
                  verify=False)

    if r.json().get('reportURL'):
        t = t.replace('excel', 'xlsx')
        with open(f'{path}.{t}', 'wb') as f:
            f.write(requests.get(r.json().get('reportURL')).content)
        print(f'Report in {path}')
    else:
        jstr = json.dumps(r.json(),indent=4,separators=(',',':'),ensure_ascii=False)
        print(jstr)
    return r.json().get('reportURL')

def get_status(search_keys, base_url, token):
    ''''Search and get AJF job status, job output, job logs.'''
    search_str = ''
    # response_file = ''
    for k, v in search_keys.items():
        # replacing special char in url string
        if isinstance(v, bool):
            v = str(v).casefold()
        elif v != '*':
            v = urllib.parse.quote(v)
        search_str += f'{k}={v}&'
        
        # non-default search keys are output response file name
        # if v != '*' and v != '20000':
        #     response_file += f'{v}_'
            
    # remove the last "&"
    search_str = search_str[:-1]
    
    CTM_headers = {
        'Authorization':f'Bearer {token}',
        }
    
    r = requests.get(url= base_url + f'/run/jobs/status?{search_str}',\
                  headers = CTM_headers,\
                  verify=False)
    jstr = json.dumps(r.json(),indent=4,separators=(',',':'),ensure_ascii=False)
    print(jstr)
    # if not r.json().get('errors'):
    #     if r.json().get('returned'): # if search result is not 0 job
    #         if path:
    #             with open(path, 'w', encoding='UTF-8') as f:
    #                 f.write(jstr)
    #                 print(f'Search results in {path}')
    #         else:
    #             print(jstr)
    #     else: # search result is 0 job
    #         print(jstr)
    # else:
    #     print(jstr)
    return r.json()

def get_output(j, keywords, base_url, token):
    CTM_headers = {
        'Authorization':f'Bearer {token}',
        }
    dct = {}
    for key in keywords:
        dct.update({key:[]})
        
    job_statueses = j.get('statuses')
    for status in job_statueses:
        jobtype = status.get('type')
        if jobtype != 'Folder' and jobtype != 'Sub-Table' and jobtype != 'Dummy' \
            and status.get('outputURI').startswith('https'):
            jobid = status.get('jobId') # <CTMserver_name>:<order_id>
            
            r = requests.get(url= base_url + f'/run/job/{jobid}/output?runNo=0',\
                          headers = CTM_headers,\
                          verify=False)
            output = r.text

            for key in keywords:
                if output.find(key) != -1:
                    dct.get(key).append(status.get('name'))
    print(dct)
    return dct               
        
        
if __name__=='__main__':
    urllib3.disable_warnings() # disable warnings when creating unverified requests
    
    parser = argparse.ArgumentParser(prog='Control-M RESTapi',\
                                     description=__doc__,\
                                    formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    
    # login = parser.add_argument_group('login', 'Login to Control-M and received a token')
    parser.add_argument('-u', '--user', help='Control-M user name')
    parser.add_argument('-p', '--password', help='Control-M user password')
    parser.add_argument('-s', '--server', default='localhost', help='Control-M Server hostname or ip')
    parser.add_argument('-P', '--port', default='8443', help='Control-M api port/tcp. By default\
                                                    "8443" for Windows and "8446" for Unix.')
    parser.add_argument('-D', '--delete', action='store_true', help='Delete ./token.cfg and ./ctmAPIverion.cfg')
    parser.add_argument('-V', '--version', action='store_true', help='Show Control-M api version')
    
    subparsers = parser.add_subparsers(dest='cmd')
    Post_parser = subparsers.add_parser('Post', description=postj.__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    Post_parser.add_argument('obj', help='POST <json file> to Control-M Server')
    Post_parser.add_argument('-S', '--service', choices=['build', 'deploy'], default='build',\
                      help='"build" to validate json or "deploy" to validate and deploy json')
     
    Folder_parser = subparsers.add_parser('Folder', description=get_folder.__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    Folder_parser.add_argument('obj', help='GET <folder name> in json from Control-M Server')
    # Folder_parser.add_argument('-P', '--path', default='',\
    #                            help='Save Control-M folder.json in <path/filename>')   

    Cal_parser = subparsers.add_parser('Cal', description=get_cal.__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    Cal_parser.add_argument('type', choices=['Regular', 'Periodic', 'RuleBasedCalendar'],\
                            help='List calendar names stored in Control-M Server in selected type.\
                                RuleBasedCalendar not supported before Control-M AAPI 9.20.250.')
    Cal_parser.add_argument('-obj', '--object', default='*', help='GET <calendar_name> definition\
                                                        in json format from Control-M Server') 
    # Cal_parser.add_argument('-P', '--path', default='',\
    #                            help='Save Control-M calendar.json in <path/filename>')   
        
    Report_parser = subparsers.add_parser('Report', description=report.__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    Report_parser.add_argument('obj', help='Generate Control-M report <report template name>')
    Report_parser.add_argument('-t', '--type', choices=['pdf', 'csv', 'excel'],\
                               default='excel', help='Control-M report format')
    Report_parser.add_argument('path', help='Save Control-M report in <path/filename>')
    
    Status_parser = subparsers.add_parser('Status', description=get_status.__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        
    Status_keys = ['limit', 'jobname', 'application', 'subApplication', 'host', 'status',\
                   'folder', 'description', 'orderDateFrom', 'orderDateTo', 'runAs',\
                   'command', 'fileName', 'resourcePool', 'ruleBasedCalendar', 'held',\
                   'folderHeld', 'cyclic', 'deleted']
    Status_help = 'Optional searching criteria. Wildcards "*", "?" supported.\
                    Comma to seperate multiple values.'
    Status_help_bool = 'Optional searching criteria.'  
    today = datetime.datetime.today().strftime("%y") + datetime.datetime.today().strftime("%m")\
            + datetime.datetime.today().strftime("%d")
        
    Status_parser.add_argument(f'--{Status_keys[0]}', default='10000', help='Limit number of jobs returned \
                                                        in search results to ?')
    Status_parser.add_argument(f'--{Status_keys[1]}', default='*', help=Status_help)
    Status_parser.add_argument(f'--{Status_keys[2]}', default='*', help=Status_help)   
    Status_parser.add_argument(f'--{Status_keys[3]}', default='*', help=Status_help) 
    Status_parser.add_argument(f'--{Status_keys[4]}', default='*', help=Status_help)
    Status_parser.add_argument(f'--{Status_keys[5]}', default='*', help=f'{Status_help} Status choices: \
                                "Ended OK", "Ended Not OK", "Executing", "Wait Condition",\
                                    "Wait Host", "Wait User".') 
    Status_parser.add_argument(f'--{Status_keys[6]}', default='*', help=f'{Status_help} \
                                                           Enter full parent folder path, \
                                                        e.g. <foldername/sub_foldername>')
    Status_parser.add_argument(f'--{Status_keys[7]}', default='*', help=Status_help)
    Status_parser.add_argument(f'--{Status_keys[8]}', default=today, help=f'{Status_help_bool} Format: YYMMDD') 
    Status_parser.add_argument(f'--{Status_keys[9]}', default=today, help=f'{Status_help_bool} Format: YYMMDD') 
    Status_parser.add_argument(f'--{Status_keys[10]}', default='*', help=Status_help) 
    Status_parser.add_argument(f'--{Status_keys[11]}', default='*', help=Status_help) 
    Status_parser.add_argument(f'--{Status_keys[12]}', default='*', help=Status_help) 
    # Status_parser.add_argument(f'--{Status_keys[13]}', default='*', help=Status_help) 
    Status_parser.add_argument(f'--{Status_keys[14]}', default='*', help=Status_help) 
    Status_parser.add_argument(f'--{Status_keys[15]}', action='store_true', help=Status_help_bool) 
    # Status_parser.add_argument(f'--{Status_keys[16]}', action='store_true', help=Status_help_bool) 
    Status_parser.add_argument(f'--{Status_keys[17]}', action='store_true', help=Status_help_bool) 
    Status_parser.add_argument(f'--{Status_keys[18]}', action='store_true', help=Status_help_bool) 
    Status_parser.add_argument('-k', '--keyword', nargs='*', help='Find <keyword> in job output')
    
    args = parser.parse_args()
    
    tokenf = f'{pwdpath}\\token.cfg'
    versionf = f'{pwdpath}\\ctmAPIverion.cfg'
    token = ''
    ctm_base_url = base_url(args.server, args.port)
    
    idle = 60*60 # express 60 minutes in seconds
    
    if args.user and args.password:
        token = login(args.user, args.password, ctm_base_url)
            
    elif os.path.isfile(tokenf):
        # time.time() returns seconds from epoch to now. Assuming token expires in 60 min
        if time.time() - os.path.getmtime(tokenf) <= idle:
            with open(tokenf, 'r') as f:
                token = f.read()
    
    if args.version:
        if os.path.isfile(versionf):
            with open(versionf, 'r') as f:
                print(f.read())
        else:
            print('Please provide username, password, hotname, port to login.')
    
    if args.delete and os.path.isfile(tokenf):
        os.remove(tokenf)
        os.remove(versionf)
        print(f'{tokenf} and {versionf} deleted')
        
    if token:
        if args.cmd == 'Post':
            postj(args.obj, args.service, ctm_base_url, token)
            
        elif args.cmd == 'Folder':
            get_folder(args.obj, ctm_base_url, token)
            
        elif args.cmd == 'Cal':
            get_cal(args.type, args.object, ctm_base_url, token)
                
        elif args.cmd == 'Report':
            report(args.obj, args.type, args.path, ctm_base_url, token)
            
        elif args.cmd == 'Status':
            keys = {Status_keys[0]: args.limit,
                    Status_keys[1]: args.jobname,
                    Status_keys[2]: args.application,
                    Status_keys[3]: args.subApplication,
                    Status_keys[4]: args.host,
                    Status_keys[5]: args.status,
                    Status_keys[6]: args.folder,
                    Status_keys[7]: args.description,
                    Status_keys[8]: args.orderDateFrom,
                    Status_keys[9]: args.orderDateTo,
                    Status_keys[10]: args.runAs,
                    Status_keys[11]: args.command,
                    Status_keys[12]: args.fileName,
                    # found no job if the job uses no quant resource. Coresponding codes: Status_parser.add_argument
                    # Status_keys[13]: args.resourcePool, 
                    Status_keys[14]: args.ruleBasedCalendar,
                    Status_keys[15]: args.held,
                    # mainframe only param. Coresponding codes: Status_parser.add_argument
                    # Status_keys[16]: args.folderHeld,
                    Status_keys[17]: args.cyclic,
                    Status_keys[18]: args.deleted,
                    }
            got_status = get_status(keys, ctm_base_url, token)
            if args.keyword:
                get_output(got_status, args.keyword, ctm_base_url, token)            
        else:
            print('One positional argument:{Post,Folder,Cal,Report, Status} required')
    else:
        print('No token obtained')