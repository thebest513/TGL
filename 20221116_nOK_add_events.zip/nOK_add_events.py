# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 12:53:50 2022
Please create a folder_lst.txt containing folder names in each line to run this script
"""

import RESTapi_func_monitor
import json
import os, psutil      
import urllib3

def nOK_add_events(j):
    ''' For Control-M folders and jobs with successors, 
        this function dig thru one JSON def to add "If - ended NOTOK, Actions - Add events",
        in order to complete jobflow in execution
    '''
    ifnOK_template =  {
            "Type": "If:CompletionStatus",
            "CompletionStatus": "NOTOK"}
    # k is objects such as top folders
    # v is what resides in a folder, such as properties, jobs, sub-folders
    for k, v in j.items():
        # str obj does not have get method
        if isinstance(v, dict):
            if v.get('eventsToAdd'):
                v.update({"IfBase:Folder:CompletionStatus_99":ifnOK_template})                    
                events = v.get('eventsToAdd').get('Events')
                for i, event in enumerate(events):
                    event_add_i_template = {
                                "Type": "Event:Add",
                                "Event": "OS_id-TO-sleep2" }
                    # event_add_i = {f'Event:Add_{i}': copy.deepcopy(event_add_i_template)}
                    event_add_i_template.update({'Event': event.get('Event')})
                    v.get("IfBase:Folder:CompletionStatus_99").update({f'Event:Add_{i}': event_add_i_template})
                    
            # None type does not have startswith method
            if v.get('Type', 'nokey').endswith('Folder'):
                for kinn, vinn in v.items():
                    if isinstance(vinn, dict):
                        nOK_add_events({kinn : vinn})
   
if __name__=='__main__':
    process = psutil.Process(os.getpid())
    print(f'Memory Usage Preloading: {round(process.memory_info().rss/1024/1024/1024,2)} GB')    
    urllib3.disable_warnings() # disable warnings when creating unverified requests 
    
    host = 'centos7msi'
    port = '8446'
    user = 'emuser'
    pswd = 'emuser'
    
    endpoint = RESTapi_func_monitor.base_url(host, port)
    token = RESTapi_func_monitor.login(user, pswd, endpoint)
    
    # folder_names = []
    with open('folder_lst.txt', 'r', encoding='UTF-8') as f:        
        for line in f:
            # folder_names.append(line.strip())
    
    # for folder_name in folder_names:
            folder_j = RESTapi_func_monitor.get_folder(line.strip(), endpoint, token)
            if folder_j:
                nOK_add_events(folder_j)
                with open(f'{line.strip()}.json', 'w', encoding='UTF-8') as f:        
                    f.write(json.dumps(folder_j, indent=4, ensure_ascii=False))
                # RESTapi_func_monitor.postj(folder_j, 'deploy', endpoint, token)
        
    process = psutil.Process(os.getpid())
    print(f'Memory Usage Postloading: {round(process.memory_info().rss/1024/1024/1024,2)} GB')