update CMR_RESOURCELOCK set LASTEND = '1' where RESOURCE_NAME = 'backrest_nodes_config' and RESOURCE_TYPE = 3 and LASTEND = '0' 
;
