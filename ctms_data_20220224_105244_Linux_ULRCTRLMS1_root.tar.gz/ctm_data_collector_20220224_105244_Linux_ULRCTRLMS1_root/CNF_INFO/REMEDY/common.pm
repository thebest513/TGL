#common.pm File

package common;
use strict;
use vars qw($VERSION @ISA @EXPORT);

#Perl Standard libs
use Cwd;
$VERSION = '0.01';

use HTTP::Tiny; 
use File::Copy;

# Constant
		
#########
   my $LogsPath = "";
   my $DirSeparator = "";

#-----------------------------------------
# Description:
#
#	Display a message to the user
#
# Params:
#	msg - the string to show the user
#-----------------------------------------
sub ShowMsg($)
{
	my $szMsg = shift;	

	printf("\n".$szMsg."\n");	
}


#-----------------------------------------
# Description:
#
#	Get the Operating System type (Windows/Unix)
#-----------------------------------------
sub GetOperatingSysType()
{
	my $temp_os = $ENV{"OS"};

	$temp_os = lc($temp_os);      #change to Lowercase

#	printf("temp_os: %s\n", $temp_os);

	my $windows_os = grep(/windows/,$temp_os);

#	printf("windows_os: %s\n", $windows_os);
	
	if ( $windows_os )
	{                    
     		return ("Windows");
     	}
	else
	{                                                               
    		return ("Unix");
	}
}
	
sub GetLogsPath
{
   if ($LogsPath ne "") {
      return $LogsPath;
   } 

   if( &IsWindows) {
      $DirSeparator = "\\";
   } 
   else 
   {
      $DirSeparator = "/";
   }

   $LogsPath = $ENV{"CONTROLM_SERVER"} . $DirSeparator."proclog" . $DirSeparator;
   return $LogsPath;
}

sub IsWindows
{
   return ($^O =~ /win/i) 
}

sub GetTempPath
{
	if (IsWindows()) 
	{
		return $ENV{"CONTROLM_SERVER"}."\\Temp\\";
	}
	else
	{
		return $ENV{"CONTROLM_SERVER"}."/tmp/";
	}
}

sub GetExecPath
{
	if (IsWindows()) 
	{
		return $ENV{"CONTROLM_SERVER"}."\\exe\\";
	}
	else
	{
		return $ENV{"CONTROLM_SERVER"}."/scripts/";
	}
}

sub GetScriptsPath
{
	if (IsWindows()) 
	{
		return $ENV{"CONTROLM_SERVER"}."\\exe\\";
	}
	else
	{
		return $ENV{"CONTROLM_SERVER"}."/scripts/";
	}
}

sub GetDataPath
{
	if (IsWindows()) 
	{
		return $ENV{"CONTROLM_SERVER"}."\\Data\\";
	}
	else
	{
		return $ENV{"CONTROLM_SERVER"} . "/data/";
	}
}

sub GetRemedyDataPath
{
	if (IsWindows())
	{
		return $ENV{"CONTROLM_SERVER"}."\\Data\\REMEDY\\";
	}
	else
	{
		return $ENV{"CONTROLM_SERVER"} ."/data/REMEDY/";
	}
}

sub GetPerlPath
{
        my $PERL_PATH=$ENV{"CTM_PERL_HOME"};
        if ( $PERL_PATH eq '')
        {
           print ("CTM_PERL_HOME environment variable not found. Exits\n");
           exit(1);
        }

	if (IsWindows())
	{
	    return $PERL_PATH."\\perl";
	}
	else
	{
           return $PERL_PATH."/perl";
	}
}

sub GetMigrateBackupDataPath
{
	if (IsWindows())
	{
		return $ENV{"CONTROLM_SERVER"}."\\upgrade\\import\\output\\definition\\data\\";
	}
	else
	{
		return $ENV{"CONTROLM_SERVER"}."/upgrade/import/output/definition/data/";
	}
}

sub ReadPasswordNoEcho
{
   my $pass;

   if (!IsWindows()) {
      system ("stty -echo");
      $pass = <STDIN>;
      system ("stty echo");
   } else {
     eval 'use Term::ReadKey;
        ReadMode \'noecho\';
        $pass = ReadLine 0;
        ReadMode \'normal\'';   
   }
   print "\n";
   chomp $pass;

   return $pass;
}

#-----------------------------------------
# Description:
#
#	General routine for actions menu display
#	and user interaction
#
# Params
#	Array of (menu item,menu action) pairs
#-----------------------------------------
sub showMenu($@)
{
	my $menu_title = shift;
	my @menu = @_;	
	my $i;
	
	my $nMenuItems = @menu;	
	$nMenuItems = $nMenuItems / 2;
	
#	printf("\nOptions\n");	
show_menu_lable:	
	
	if ( IsWindows() ) {
		system("cls");
	}
	else {
		system("clear");
	}

	printf("%s\n", $menu_title);
	for( $i = 0 ; $i < $nMenuItems; $i++)
	{	
		my $szDisplay = @menu[$i*2];
		my $szAction  = @menu[$i*2 + 1];			

		printf("%d) %s\n", $i + 1 , $szDisplay);
	}
	
	my $Selection = 0;
	
	printf("\nSelect an option: ");		
	$Selection = <STDIN>;
	printf("\n");			
	if( $Selection < 1 ||  $Selection > $nMenuItems  )
	{
		printf("Please select an option between 1 and %d\n", $nMenuItems );		
                sleep (3);
		goto show_menu_lable;		
	}
	
	my $new_value;

	my $szAction  = '@main::basic_params[($Selection -1)*4 + 3]='.@menu[ ($Selection -1)*2 + 1];				
	
	#------------------------------------
	# now perform the perl function 
	# associated with the menu item
	#------------------------------------
	eval $szAction; warn $@ if $@;

	printf("ECHO for new_value from menu: %s\n", $new_value);
}

sub getUserConfirmationYN()
{
	my $confirm = "";
	while ( !($confirm =~ /^y$|^n$/i) ) {
		$confirm= <STDIN>;
		chomp($confirm);
		
		if ( !($confirm =~ /^y$|^n$/i) ) { printf("Answer Y or N :"); }
	}
	
	return $confirm;
}

sub returnToMainMenu()
{
	my $confirm = "";
	printf("Press <ENTER> to continue\n");
	while ( "$confirm" ne "\n" ) {
		$confirm= <STDIN>;
	}
}

sub checkAuthorizations()
{
   my $id_name;
   my $dir_name;
   my $ls_output;
   my @arr_dir;
   my $found;
   my $line;
   my $curruserdomain = $ENV{"USERDOMAIN"}."\\".$ENV{"USERNAME"};


   if (common::IsWindows) 
   {	
      #  Check if the logged in user belongs to adminstrators group.
      open PH, "net LOCALGROUP Administrators|";
      $found = 0;
      while (<PH>)
      {
         $line = $_;
         chomp($line);
         if("$curruserdomain" eq "$line")
         {
            $found=1;
            last;
         }
      }

      close PH;

      if($found)
      {
         return(1);
      }
      else
      {
         return(0);
      }

   }
   else
   {
      #  Check if the user is a controlm server user
      $id_name=`id | cut -d'(' -f2 | cut -d')' -f1`;
      chop($id_name);
      $dir_name=`dirname $0`;
      $ls_output=`ls -ld $dir_name`;
      $ls_output =~ s/\s+/ /g;
      @arr_dir=split(/ /,$ls_output);
      if("$id_name" eq "$arr_dir[2]")
      {
         return(1);
      }
      else
      {
         print "You are not authorized to execute this utility! Only $arr_dir[2] user can run this utility.\n";
         return(0);
      }
   }
}

sub ResetRemedyPassword()
{
   my $ResetPassword = "";
   my $line;
   my $loginPos;
   my $endLoginPos;
   my $remedyUser;
   my $pwd_str="";
   my $pwd_str_confirm="";
   my $bFirstTime = 1;
   my $out_log=GetTempPath() . "ResetPassword_" . $$;

   if (IsWindows())
   {
      $out_log = "\"". $out_log . "\"";
   }

#       Get remedy LoginUser from XML file
   my $RemedyConfFile=GetRemedyDataPath() ."RemedyConf.xml";

   if(!open(REM_FH,"<".$RemedyConfFile))
   {
      printf ("Could not open file %s Aborting...\n",$RemedyConfFile);
      returnToMainMenu();
      return(1);
   }

   my $found=0;

   while (<REM_FH>)
   {
      $line = $_;
      $loginPos = index($line,"<LoginUser>");
      if($loginPos >= $[)
      {
         $found = 1;
         last;
      }
   }
   close REM_FH;

   if(!$found)
   {
      printf("Could not find LoginUser tab in %s \n",$RemedyConfFile);
      returnToMainMenu();
      return(2);
   }

   $loginPos = $loginPos + 11;
   $endLoginPos = index($line,"<",$loginPos);
   $remedyUser = substr($line,$loginPos,$endLoginPos - $loginPos);
        
#       Get Password from User
   while ( $bFirstTime || ("$pwd_str" ne "$pwd_str_confirm") ) 
   { 
      printf("\nEnter password: ");
      $pwd_str = ReadPasswordNoEcho();
      chomp $pwd_str;

      printf("Confirm password: ");
      $pwd_str_confirm = ReadPasswordNoEcho();
      chomp $pwd_str_confirm;

      if ("$pwd_str" ne "$pwd_str_confirm") 
      { 
         printf("Password not confirmed !!! \n");
      }
      $bFirstTime = 0;
   }
	
#       Update log
   logEntry('remedy_configure.log', 'ResetRemedyPassword', "Reseting Remedy password for user".$remedyUser); 

#  Delete user. Utility succeeds even it did not exist   
   $ResetPassword = "ctmkeystore_mng -DELETE REMEDY " . $remedyUser;
   $ResetPassword = $ResetPassword . " > ". $out_log;
   my $sRet;
   $sRet = system($ResetPassword);
   if($sRet < 0)
   {
      printf("failed to activate ctmkeystore_mng\n");
      logEntry('remedy_configure.log', 'ResetRemedyPassword', "failed to activate ctmkeystore_mng"); 
      returnToMainMenu();
      return(3);
   } 
   $sRet = $sRet >> 8;
   if($sRet != 0)
   {
      printf("ctmkeystore_mng failed to delete user %s\n",$remedyUser);
      logEntry('remedy_configure.log', 'ResetRemedyPassword', "ctmkeystore_mng failed to delete user ".$remedyUser); 
      return(4);
      returnToMainMenu();
   }

   $ResetPassword = "ctmkeystore_mng -NEW REMEDY ".$remedyUser ;
   if (IsWindows()){
	$ResetPassword = $ResetPassword . " \"".$pwd_str . "\""." > ". $out_log;
   }
   else
   {
    $ResetPassword = $ResetPassword . " " .$pwd_str ." > ". $out_log;
   }
   $sRet = system($ResetPassword);
   if($sRet < 0)
   {
      printf("failed to activate ctmkeystore_mng to update password\n");
      logEntry('remedy_configure.log', 'ResetRemedyPassword', "failed to activate ctmkeystore_mng to activate password"); 
      returnToMainMenu();
      return(5);
   } 
   $sRet = $sRet >> 8;
   if($sRet != 0)
   {
      printf("ctmkeystore_mng failed to update password of user %s\n",$remedyUser);
      logEntry('remedy_configure.log', 'ResetRemedyPassword', "ctmkeystore_mng failed to password of user ".$remedyUser); 
      returnToMainMenu();
      return(6);
   }
   
   printf("Remedy Server password was set successfully \n");
   system("ctmipc -dest CE -msgid cfg");

   returnToMainMenu();
   return(0);
}

sub TestConfiguration()
{
   my $TestUtil = "";
   my $hostname;
   my $now_string = localtime();  

   $hostname = `hostname`;
   chop($hostname);
   #Example: ctmipc -dest CE -msgid ctl -data "CtmRemedyClientManager do_remedy \"Highly BOBO XXX\" \"my new descr with spaces\" H"
   #Replaced enclosing < and > with [ and ], because the shell does not treat \" as literal, so the text starting with "Host:" is outside " closure, so the shell will interpret it as special characters. 
   $TestUtil = "ctmipc -dest CE -msgid ctl -data \"CtmRemedyClientManager do_remedy ";
   $TestUtil = $TestUtil. "\\\"Test Remedy Client\\\" ";
   $TestUtil = $TestUtil. "\\\"Host: [$hostname] Date: [$now_string]\\\" L\"";
   my $pid = open PH, $TestUtil . " 2>&1|";
   while (<PH>) {
      my $screen_output = $_;
#     on HP ESS package ouputs a bizare message with ESS BCM_...
      if(!( $screen_output =~ /ESS BCM/))
      {
         printf("%s", $screen_output);
         logEntry('remedy_configure.log', 'TestUtil', $screen_output); 
      }
   }
   close PH;

   returnToMainMenu();
}

#---------------------------------------------------------------------------
# Description:
#	Adds an entry into a log file pointed by the 1st parameter and located 
#   under <EM home>/log directory.
#	If the specified log file does not exist, it will be created
#
#   entry format :
#   <date time> <calling application name> <message text>
#
# Input Params:
#	1. name of the log file
#	2. name of calling application / function
#	3. message text
#
# Output Params: N/A
#---------------------------------------------------------------------------
sub	logEntry($$$)
{
	my $logName = shift;
	my($szAppName,$szMsg) = @_;
	my $now_string = localtime();  
    	my $logsPath = common::GetLogsPath;

	open(LOG_HDL, ">>" . $logsPath . $logName);
	printf(LOG_HDL  $now_string . " " . $szAppName . "\t ".$szMsg."\n");
	close(LOG_HDL);
}


#---------------------------------------------------------
# Package must end with statment returning true
#---------------------------------------------------------
1;
