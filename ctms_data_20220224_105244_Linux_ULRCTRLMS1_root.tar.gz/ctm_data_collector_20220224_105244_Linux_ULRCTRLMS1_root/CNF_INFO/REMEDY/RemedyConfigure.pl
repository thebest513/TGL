use strict;

#Internal includes
use common;
use File::Copy;

my $g_MainMenuTitle = "=== Remedy configuration menu ===\n";
my @g_MainMenu =  ( 
		( "Basic parameters",		'main::ViewAndSetParams();'  ),  
		( "Reset user password",	'main::ResetRemedyPassword();'  ), 
		( "Test configuration (requires running server)",		'main::TestConfiguration();'  ), 
		( "Quit"              ,		'main::ExitMenu(2);')  	
	);

my $g_RemedyLog = "remedy_configure.log";

# parameters for migration

my $migration_mode="";

my $server_name = 1;
my $port_number = 2;
my $user_name = 3;
my $open_schema6 = 4;
my $requester_name = 5;
my $open_status6 = 6;
my $category_name = 7;
my $type = 8;
my $item = 9;
my $requester_login = 10;
my $case_source = 11;
my $case_type = 12;
my $close_schema6 = 13;
my $close_status6 = 14;
my $open_schema7 = 15;
my $first_name = 16;
my $last_name = 17;
my $impact = 18;
my $action = 19;
my $open_status7 = 20;
my $close_schema7 = 21;
my $close_status7 = 22;
my $assignee = 23;
my $assignee_login_id = 24;

#---------------------------------------------------------------------------
#  Parameters
#
#	usage: remedy_configure
#
#	Params: N/A
#---------------------------------------------------------------------------	
main(@ARGV);

ExitMenu(0);

sub ExitMenu($)
{
	my $rc = shift;

	common::logEntry ( $g_RemedyLog, 'remedy_configure' , " ************************ Exiting *************************");

	exit($rc);
}

#---------------------------------------------------------------------------
# Descripption:
#
#	The main program
#
#	Params: N/A
#---------------------------------------------------------------------------	
sub main()
{
    $migration_mode = shift;
    
	common::logEntry ( $g_RemedyLog, 'remedy_configure' , " ************************ Starting *************************");
	
	common::checkAuthorizations(); # will be implemented on CTM side only
	
	if ($migration_mode ne "MIGRATION")
	{
	   common::showMenu($g_MainMenuTitle, @g_MainMenu );
	}
	else 
	{
       if (handling_migration() > 0)
       {
          ExitMenu (1);
       }
    }	
	ExitMenu(0);
}

sub ResetRemedyPassword()
{
	common::ResetRemedyPassword();
	common::showMenu($g_MainMenuTitle, @g_MainMenu);	
}

sub TestConfiguration()
{
	common::TestConfiguration();
	common::showMenu($g_MainMenuTitle, @g_MainMenu);	
}

#-----------------------------------------
# Description:
#	Runs the database validator
#-----------------------------------------
sub ViewAndSetParams()
{
	my $bRet= 0;
	
	my %basic_params = ();
	
    $basic_params{1} = ["ServerHostName", "Remedy Server Name", "", ""];
	$basic_params{2} = ["Port", "Remedy Server Port", "", ""];
	$basic_params{3} = ["LoginUser", "Remedy User Name - the user used to login Remedy server", "", ""];
	$basic_params{4} = ["Login", "Login User - used to create HelpDesk ticket in Remedy 6", "", ""];
	$basic_params{5} = ["FirstName", "First User Name - used to create incident ticket in Remedy 7", "", ""];
	$basic_params{6} = ["LastName", "Last User Name - used to create incident ticket in Remedy 7", "", ""];
	
	my $rc = ReadConfiguration(\%basic_params);

    if ( $rc > 0 )
    {
       my $selection = showXmlParamsMenu(\%basic_params);
	   if ($selection =~ /^s$/i) { 
	  	  $rc = SaveConfiguration(\%basic_params); 
		  system("ctmipc -dest CE -msgid cfg");
	   }
	}
    
	if ( $rc <= 0)
	{
	   common::returnToMainMenu();
	}
	common::showMenu($g_MainMenuTitle, @g_MainMenu);	
}


#-----------------------------------------
# Description:
#
#	General routine for parameters menu display
#	and user interaction
#
# Params
#	Array of (menu item, XML parameter name (not displayed), displayed parameter name, parameter old value, parameter new value) 
#-----------------------------------------
sub showXmlParamsMenu($)
{
	my $menu_ref = shift;

	my @menu = values %$menu_ref;
	my $nMenuItems = @menu;	
	
	my $bParamsChanged = 0;

show_menu_lable:	
	
	if (common::IsWindows) { system("cls"); }
	else { system("clear"); }
	
	printf("=== Review and configure basic Remedy parameters ===\n\n");
	for( my $i = 0 ; $i < $nMenuItems; $i++)
	{	
		my $szDisplay = "$menu_ref->{$i+1}->[1] : " . "$menu_ref->{$i+1}->[3]";
		printf("%d) %s\n", $i + 1 , $szDisplay);
	}
	printf("\n====  <C> - Cancel    <S> - Save configuration  ====\n");
	
	my $Selection = "";
	
	printf("\nEnter command or item number you wish to change: ");		
	$Selection = <STDIN>;
	chomp($Selection);
	printf("\n");			
	
	if ($Selection >= 1 &&  $Selection <= $nMenuItems){
		printf("Enter a new value for %s : ", $menu_ref->{$Selection}->[1]);
		
		my $szAction  = '$menu_ref->{$Selection}->[3]=main::ReadNewValue()';				
	
		#------------------------------------
		# now perform the perl function 
		# associated with the menu item
		#------------------------------------
		eval $szAction; warn $@ if $@;

		if ( "$menu_ref->{$Selection}->[2]" ne "$menu_ref->{$Selection}->[3]" ) { 
			$bParamsChanged = 1;
		}
	
		goto show_menu_lable;		
	} 
	elsif ($Selection =~ /^c$/i) {
		if ($bParamsChanged == 0) { printf("Cancel? (Y/N) "); }
		else {
			printf("Changes were made for basic Remedy parameters, but are not saved yet.\n");
			printf("Cancel without saving the changes? (Y/N) ");
		}
	}
	elsif ($Selection =~ /^s$/i) { 
		printf("Save configuration? (Y/N) ");
	}
	else { goto show_menu_lable; }
	
	my $user_confirm = common::getUserConfirmationYN();
	if ( $user_confirm =~ /^n$/i ) { goto show_menu_lable; }
	
	return $Selection;
}

sub ReadConfiguration($)
{
	my $RemedyConfXml = GetRemedyConfFile();

	my $basic_params_ref = shift;
	
	if ( ! open (FILE_HDL, "<" . $RemedyConfXml ) ) { 
		printf("Cannot open %s\n", $RemedyConfXml); 
		return 0;
	}
	
	my @file_hdl = <FILE_HDL>;
	close (FILE_HDL);
	
	my $file_str = join('', @file_hdl);
	
	if ( !getConnectionSettings($basic_params_ref, $file_str) || 
		 !getRemedyFields($basic_params_ref, $file_str))
	{
		 printf("One or more of basic Remedy connection parameters are missing in RemedyConf.xml.\n");
		 printf("Cannot read configuration. Returning to main menu...\n\n");
		 return 0;
	}
	
	return 1;
}

sub SaveConfiguration($)
{
	my $RemedyConfXml = GetRemedyConfFile();

	my $basic_params_ref = shift;
	
	if ( ! open (FILE_HDL, "<" . $RemedyConfXml) ) { 
		printf("Cannot open %s\n", $RemedyConfXml);
		return 0;
	}
	
	my @file_hdl_in = <FILE_HDL>;
	close (FILE_HDL);
	
	my $file_str = join('', @file_hdl_in);
		
	if ( !setConnectionSettings($basic_params_ref, \$file_str) || 
		 !setRemedyFields($basic_params_ref, \$file_str))
	{
		 printf("One or more of basic Remedy connection parameters are missing in RemedyConf.xml.\n");
		 printf("Cannot save configuration. Returning to main menu...\n\n");
		 return 0;
	}

	if ( -e $RemedyConfXml . ".old") { unlink $RemedyConfXml . ".old"; }
	rename $RemedyConfXml, $RemedyConfXml . ".old"; 
	if ( ! open (FILE_HDL, ">" . $RemedyConfXml) ) 
	{ 
		printf("Cannot open %s to save made changes\n", $RemedyConfXml);
		return 0;
	}
	
	print FILE_HDL $file_str;
    
    close FILE_HDL;
    
#	printf("********************************** NEW FILE CONTENT ********************************\n");
#	for ($i=0; $i<@file_hdl_out; $i++) {
#		printf("%s\n", @file_hdl_out[$i]);
#	}
   
    return 1;
}

sub getAttributes($)
{
	my $attrs_str = shift;
	my %attrs_arr;
	
#	printf("INPUT ATTRIBUTES STR===%s===\n", $attrs_str);
	while ($attrs_str ne "") {
		my $name = $attrs_str;
		my $value = $attrs_str;
		
		$name =~ s/\s//;
		$name =~ s/=.*//;
		$value =~ s/$name=\"//;
		$value =~ s/\".*//;
		$attrs_str =~ s/$name=\"$value\"//;
		$attrs_str =~ s/\s//;
		$attrs_str =~ s/\///;
		
#		printf("attr name=<%s> attr value=<%s> attr_str=<%s>\n", $name, $value, $attrs_str);
		$attrs_arr{$name}=$value;
	}
	
	return %attrs_arr;
}

sub getElementValue($$$)
{
	my $elmName = shift;
	my $xmlFile_str = shift;
	my $elmValue_ref = shift;
	
	my $elmValue = $xmlFile_str;
	
	$elmValue =~ s/(((\s|\t|\n|\r|.)*?)<$elmName>)//; 
	if ($& eq "") { return 0; }
	
	$elmValue =~ s/(((\s|\t|\n|\r)*?)<\/$elmName>((\s|\t|\n|\r|.)*))//;
	if ($& eq "") { return 0; }

    $$elmValue_ref = $elmValue;
	return 1;
}

sub getNodeStr($$$)
{
	my $nodeName = shift;
	my $xmlFile_str = shift;
	my $nodeContent_ref = shift;

	my $nodeContent = $xmlFile_str;
	
	$nodeContent =~ /(((\s|\t)*?)<$nodeName>)/; 
	my $offset = $2;
	if ($& eq "") { return 0; }
	
	$nodeContent =~ s/(((\s|\t|\n|.)*?)<$nodeName>)/$offset<$nodeName>/; 
	
	$nodeContent =~ s/(<\/$nodeName>((\s|\t|\n|.)*))/<\/$nodeName>/;
	if ($& eq "") { return 0; }
	
	$$nodeContent_ref = $nodeContent;
	return 1;
}

sub getNodesArray($$$)
{
	my $nodeName = shift;
	my $nodeXPath = shift;
	my $xmlFile_str = shift;
	my @foundNodes = ();

	while ( $xmlFile_str =~ /(((\s|\t|\n|.)*?)<$nodeName>)/ ) {
		my $nodeContent = $xmlFile_str;
		$nodeContent =~ /(((\s|\t)*?)<$nodeName>)/; 
		my $offset = $2;
		$nodeContent =~ s/(((\s|\t|\n|.)*?)<$nodeName>)/$offset<$nodeName>/; 
		$xmlFile_str = $';
		$nodeContent =~ s/(<\/$nodeName>((\s|\t|\n|.)*))/<\/$nodeName>/;
		push( @foundNodes, $nodeContent);
	}
	return @foundNodes;
}

sub setElementValue($$$)
{
	my $elmName = shift;
	my $elmValue = shift;
	my $file_str_ref = shift;
	
	my $file_str = $$file_str_ref;
	my $offset;
	$file_str =~ /<$elmName>((\s|\t|\n|.)*?)>((\s|\t|\n)*?)<\/$elmName>/;
	$offset = $3;

	$elmValue =~ />*/;
	$file_str =~ s/<$elmName>((\s|\t|\n|.)*?)<\/$elmName>/<$elmName>$elmValue$offset<\/$elmName>/;
	if ($& eq "") { return 0; }
	
	$$file_str_ref = $file_str;
	return 1;
}

sub createElement($$)
{
	my $elmName = shift;
	my $elmValue = shift;
	
	my $outStr = "<" . $elmName . ">" . $elmValue . "</" . $elmName . ">\n";
	return $outStr;
}

sub getConnectionSettings($$)
{
	my $basic_params_ref = shift;
	my $file_str = shift;
	my $test = "";

	my $ConnectionSettings = "";
	if ( !getNodeStr("ConnectionSettings", $file_str, \$ConnectionSettings) ) { return 0; }
	for (my $i=0; $i < 3; $i++) {
		my $nodeValue = "";
		if (!getElementValue($basic_params_ref->{$i+1}->[0], $ConnectionSettings, \$nodeValue)) { return 0; }

		$basic_params_ref->{$i+1}->[2] = $nodeValue; # params under connection settings are simple elements
		$basic_params_ref->{$i+1}->[3] = $basic_params_ref->{$i+1}->[2]; # placeholder for a new value
	}
	return 1;
}

sub setConnectionSettings($$)
{
	my $basic_params_ref = shift;
	my $file_str_ref = shift;
	
	my $ConnectionSettings = "";
	if ( !getElementValue("ConnectionSettings", $$file_str_ref, \$ConnectionSettings) ) { return 0; }
	
	if ( !setElementValue($basic_params_ref->{1}->[0], $basic_params_ref->{1}->[3], \$ConnectionSettings) ) { return 0; }
	if ( !setElementValue($basic_params_ref->{2}->[0], $basic_params_ref->{2}->[3], \$ConnectionSettings) ) { return 0; }
	if ( !setElementValue($basic_params_ref->{3}->[0], $basic_params_ref->{3}->[3], \$ConnectionSettings) ) { return 0; }

	return setElementValue("ConnectionSettings", $ConnectionSettings, $file_str_ref);;
}

sub getRemedyFields($$)
{
	my $basic_params_ref = shift;
	my $file_str = shift;
	
	my $bRemedy6Found = 0;
	my $bRemedy7Found = 0;
	
	my @RemedyServers = getNodesArray("RemedyServer", "", $file_str);

	if ( scalar(@RemedyServers) <= 1 || scalar(@RemedyServers) > 2 ) { return 0; }
	
	for (my $i=0; $i < 2; $i++) {
		my $RemedyVersion = "";
		if (!getElementValue("Version", $RemedyServers[$i], \$RemedyVersion)) { return 0; }
		
		if ("$RemedyVersion" eq "6") { 
			if ( !getRemedy6($basic_params_ref, $RemedyServers[$i]) ) { return 0; }
			$bRemedy6Found = 1; 
		}
		if ("$RemedyVersion" eq "7") { 
			if ( !getRemedy7($basic_params_ref, $RemedyServers[$i]) ) { return 0; }
			$bRemedy7Found = 1;
		}
	}	
	return ( $bRemedy6Found && $bRemedy7Found );
}

sub setRemedyFields($$)
{
	my $basic_params_ref = shift;
	my $file_str_ref = shift;

	my $bRemedy6Found = 0;
	my $bRemedy7Found = 0;
	 
	my @RemedyServer = getNodesArray("RemedyServer", "", $$file_str_ref);

    if ( scalar(@RemedyServer) <= 1 || scalar(@RemedyServer) > 2 ) { return 0; }
	for (my $i=0; $i < 2; $i++)
	{
		my $RemedyVersion = "";
		if (!getElementValue("Version", $RemedyServer[$i], \$RemedyVersion)) { return 0; }		
		if ("$RemedyVersion" eq "6") 
		{
		   if ($migration_mode ne "MIGRATION")
		   {
			  if ( !setRemedy6($basic_params_ref, \$RemedyServer[$i]) ) { return 0; } 
		   }
		   else
		   {
		      if ( !setRemedy6ForMigration($basic_params_ref, \$RemedyServer[$i]) ) { return 0; }
           }
	      $bRemedy6Found = 1; 
	    }
	    if ("$RemedyVersion" eq "7")
	    {
	       if ($migration_mode ne "MIGRATION")
	       {
	          if ( !setRemedy7($basic_params_ref, \$RemedyServer[$i]) ) { return 0; }
	       }
	       else
	       {
	          if ( !setRemedy7ForMigration($basic_params_ref, \$RemedyServer[$i]) ) { return 0; }
	       }
	       $bRemedy7Found = 1;
	    }
    } # loop
	
    if ( $bRemedy6Found == 0 && $bRemedy7Found == 0 ) { return 0; }
	
    my $tmp ="";
    for (my $i=0; $i < scalar(@RemedyServer); $i++) 
    {
	    $tmp .= $RemedyServer[$i];
    }
	
    return setElementValue("RemedyServers", $tmp, $file_str_ref);
}

sub getRemedyFields4Open($)
{
	my $file_str = shift;
	
	my @Actions = getNodesArray("Action", "", $file_str);
	if ( scalar(@Actions) <= 1 || scalar(@Actions) > 2 ) { return 0; }
	for (my $i=0; $i < scalar(@Actions); $i++)
	{
		my $ActionType = "";
		if (!getElementValue("Type", $Actions[$i], \$ActionType)) { return 0; }

		if ("$ActionType" eq "Open")
		{
			return getNodesArray("RemedyField", "", $Actions[$i]);
		}
	}
	return (); # empty array
}

sub getAndSetRemedyFields4OpenMigration($$$)
{
	my $file_str_ref = shift;
	my $basic_params_ref = shift;
	my $RemedyVersion = shift;

    my $open_schema_ver;

	if ($RemedyVersion eq "6")
	{  
	   $open_schema_ver = $open_schema6;
	}
	else #version 7
	{
	   $open_schema_ver = $open_schema7;
	}
	
    my @Actions = getNodesArray("Action", "", $$file_str_ref);
	if ( scalar(@Actions) <= 1 || scalar(@Actions) > 2 ) { return 0; }

	my $ActionType = "";
		
	if (!getElementValue("Type", $Actions[0], \$ActionType)) { return 0; }
	if ("$ActionType" eq "Open")
	{
       if ( !getElementValue("SchemaName", $Actions[0], \$ActionType) ) { return 0; }
       if ( !setElementValue("SchemaName", $basic_params_ref->{$open_schema_ver}->[3], \$Actions[0]) ) { return 0; }
	}
    else
    {
       return 0;
    }

    my $bParamFound = 0;
    my @RemedyFields = getNodesArray("RemedyField", "", $Actions[0]);
    if ($RemedyVersion eq "6")
    {
       for (my $i = 0; $i < scalar(@RemedyFields); $i++)
	   {
	  	   my $Name = "";
		   if ( !getElementValue("Name", $RemedyFields[$i], \$Name) ) { return 0; }

		   if ("$Name" eq "Name")
		   {
		      if ( !setElementValue("Value", $basic_params_ref->{$requester_name}->[3], \$RemedyFields[$i]) )
              {
                 return 0;
              }
		      $bParamFound = 1;
		   }
		   if ("$Name" eq "Status")
		   {
              if ( !setElementValue("Value", $basic_params_ref->{$open_status6}->[3], \$RemedyFields[$i]) )
              {
                 return 0;
              }
 		      $bParamFound = 1;
		   }
		   if ("$Name" eq "Category")
		   {
		      if ( !setElementValue("Value", $basic_params_ref->{$category_name}->[3], \$RemedyFields[$i]) )
              {
                 return 0;
              }
		      $bParamFound = 1;
		   }
		   if ("$Name" eq "type")
		   {
		      if ( !setElementValue("Value", $basic_params_ref->{$type}->[3], \$RemedyFields[$i]) )
              {
                 return 0;
              }
		      $bParamFound = 1;
           }
		   if ("$Name" eq "Item")
		   {
		      if ( !setElementValue("Value", $basic_params_ref->{$item}->[3], \$RemedyFields[$i]) )
              {
                 return 0;
              }
		      $bParamFound = 1;
	       }
		   if ("$Name" eq "Login")
		   {
              if ( !setElementValue("Value", $basic_params_ref->{$requester_login}->[3], \$RemedyFields[$i]) )
              {
                 return 0;
              }
		      $bParamFound = 1;
		   }
		   if ("$Name" eq "Source")
		   {
		      if ( !setElementValue("Value", $basic_params_ref->{$case_source}->[3], \$RemedyFields[$i]) )
              {
                 return 0;
              }
		      $bParamFound = 1;
		   }
		   if ("$Name" eq "Case Type")
		   {
		      if ( !setElementValue("Value", $basic_params_ref->{$case_type}->[3], \$RemedyFields[$i]) )
              {
                 return 0;
              }
		      $bParamFound = 1;
		   }
	   } # loop
  } #if remedy 6
  else #remedy 7
  {
	 for (my $i = 0; $i < scalar(@RemedyFields); $i++)
	 {
	     my $Name = "";
	     if ( !getElementValue("Name", $RemedyFields[$i], \$Name) ) { return 0; }

	     if ("$Name" eq "FirstName")
	     {
	        if ( !setElementValue("Value", $basic_params_ref->{$first_name}->[3], \$RemedyFields[$i]) ) { return 0; }
	        $bParamFound = 1;
	     }
	     if ("$Name" eq "LastName")
	     {
	        if ( !setElementValue("Value", $basic_params_ref->{$last_name}->[3], \$RemedyFields[$i]) ) { return 0; }
	        $bParamFound = 1;
	     }
	     if ("$Name" eq "Impact")
	     {
	        if ( !setElementValue("Value", $basic_params_ref->{$impact}->[3], \$RemedyFields[$i]) ) { return 0; }
	        $bParamFound = 1;
	     }
	     if ("$Name" eq "Action")
	     {
	        if ( !setElementValue("Value", $basic_params_ref->{$action}->[3], \$RemedyFields[$i]) ) { return 0; }
	        $bParamFound = 1;
	     }
	     if ("$Name" eq "Status")
	     {
	        if ( !setElementValue("Value", $basic_params_ref->{$open_status7}->[3], \$RemedyFields[$i]) ) { return 0; }
	        $bParamFound = 1;
	     }
	  } # loop
  } # remedy 7

  if ( $bParamFound == 0 ) { return 0; }

  my $tmp = "";
  for (my $i=0; $i < scalar(@RemedyFields); $i++)
  {
      $tmp .= $RemedyFields[$i];
  }

  if (!setElementValue("RemedyFields", $tmp, \$Actions[0]))
  {
     return 0;
  }

  $tmp ="";
  for (my $i=0; $i < scalar(@Actions); $i++)
  {
       $tmp .= $Actions[$i];
  }

  if (!setElementValue("Actions", $tmp, $file_str_ref))
  {
     return 0;
  }

  return 1;
}

sub getAndSetRemedyFields4CloseMigration($$$)
{
  my $file_str_ref = shift;
  my $basic_params_ref = shift;
  my $RemedyVersion = shift;

  my $close_schema_ver;

  if ($RemedyVersion eq "6")
  {  
     $close_schema_ver = $close_schema6;
  }
  else #version 7
  {
     $close_schema_ver = $close_schema7;
  }
	
  my @Actions = getNodesArray("Action", "", $$file_str_ref);
  if ( scalar(@Actions) <= 1 || scalar(@Actions) > 2 )
  {
     return 0;
  }

  my $ActionType = "";
  if (!getElementValue("Type", $Actions[1], \$ActionType)) { return 0; }
  if ("$ActionType" eq "Close")
  {
     if (!getElementValue("SchemaName", $Actions[1], \$ActionType))
     {
        return 0;
     }
     if (!setElementValue("SchemaName", $basic_params_ref->{$close_schema_ver}->[3], \$Actions[1]))
     {
        return 0;
     }
  }
  else
  {
     return 0;
  }

  my $bParamFound = 0;
  my @RemedyFields = getNodesArray("RemedyField", "", $Actions[1]);

  if ($RemedyVersion eq "6")
  {
     for (my $i = 0; $i < scalar(@RemedyFields); $i++)
     {
	     my $Name = "";
	     if ( !getElementValue("Name", $RemedyFields[$i], \$Name) ) { return 0; }

         if ("$Name" eq "Status")
	     {
	        if ( !setElementValue("Value", $basic_params_ref->{$close_status6}->[3], \$RemedyFields[$i]) ) { return 0; }
	        $bParamFound = 1;
	     }
     } # loop
  }
  else #remedy 7
  {
     for (my $i = 0; $i < scalar(@RemedyFields); $i++)
     {
	     my $Name = "";
	     if ( !getElementValue("Name", $RemedyFields[$i], \$Name) ) { return 0; }

	     if ("$Name" eq "Status")
	     {
	        if ( !setElementValue("Value", $basic_params_ref->{$close_status7}->[3], \$RemedyFields[$i]) ) { return 0; }
 	        $bParamFound = 1;
		 }
		 if ("$Name" eq "Assignee")
		 {
		    if ( !setElementValue("Value", $basic_params_ref->{$assignee}->[3], \$RemedyFields[$i]) ) { return 0; }
		    $bParamFound = 1;
		 }
		 if ("$Name" eq "Assignee Login ID")
		 {
		    if ( !setElementValue("Value", $basic_params_ref->{$assignee_login_id}->[3], \$RemedyFields[$i]) ) { return 0; }
		    $bParamFound = 1;
		 }
      } # loop
  } # remedy 7

  if ( $bParamFound == 0 ) { return 0; }

  my $tmp = "";
  for (my $i=0; $i < scalar(@RemedyFields); $i++)
  {
    $tmp .= $RemedyFields[$i];
  }

  if (!setElementValue("RemedyFields", $tmp, \$Actions[1]))
  {
     return 0;
  }
     
  $tmp ="";
  for (my $i=0; $i < scalar(@Actions); $i++)
  {
       $tmp .= $Actions[$i];
  }

  if (!setElementValue("Actions", $tmp, $file_str_ref))
  {
     return 0;
  }
  
  return 1;
}

sub getRemedy6($$)
{
	my $basic_params_ref = shift;
	my $file_str = shift;
	
	my $bParamFound = 0;
	my @RemedyFields = getRemedyFields4Open($file_str);
	for (my $i = 0; $i < scalar(@RemedyFields); $i++)
	{
		my $Name = "";
		if ( !getElementValue("Name", $RemedyFields[$i], \$Name) ) { return 0; }
		
		if ("$Name" eq "$basic_params_ref->{4}->[0]")
    {
  		 if ( !getElementValue("Value", $RemedyFields[$i], \$basic_params_ref->{4}->[2]) ) { return 0; }
			
			 $basic_params_ref->{4}->[3] = $basic_params_ref->{4}->[2]; # placeholder for a new value
			 $bParamFound = 1;
		}
	}
	return $bParamFound;
}

sub setRemedy6($$)
{
	my $basic_params_ref = shift;
	my $file_str_ref = shift;
	
	my $bParamFound = 0;
	my @RemedyFields = getRemedyFields4Open($$file_str_ref);
	for (my $i = 0; $i < scalar(@RemedyFields); $i++)
	{
		my $Name = "";
		if ( !getElementValue("Name", $RemedyFields[$i], \$Name) ) { return 0; }
		if ("$Name" eq "$basic_params_ref->{4}->[0]") {
			if ( !setElementValue("Value", $basic_params_ref->{4}->[3], \$RemedyFields[$i]) ) { return 0; }
			$bParamFound = 1;
		}
	}
	
	if ( $bParamFound == 0 ) { return 0; }
	
	my $tmp = "";
	for (my $i=0; $i < scalar(@RemedyFields); $i++) {
		$tmp .= $RemedyFields[$i];
	}
	
	return setElementValue("RemedyFields", $tmp, $file_str_ref);
}

sub setRemedy6ForMigration($$)
{
	my $basic_params_ref = shift;
	my $file_str_ref = shift;
	
	my $bParamFound = 0;
	my $RemedyVersion = "6";
    my $tmp = "";
	
	if (!getAndSetRemedyFields4OpenMigration($file_str_ref, $basic_params_ref, $RemedyVersion))
    {
       return 0;
    }

    if (!getAndSetRemedyFields4CloseMigration($file_str_ref, $basic_params_ref, $RemedyVersion))
    {
       return 0;
    }
  
	return 1 ;
}

sub getRemedy7($$)
{
	my $basic_params_ref = shift;
	my $file_str = shift;
	
	my $bParamFound_1 = 0;
	my $bParamFound_2 = 0;
	my @RemedyFields = getRemedyFields4Open($file_str);
	for (my $i = 0; $i < scalar(@RemedyFields); $i++)
	{
		my $Name = "";
		if (!getElementValue("Name", $RemedyFields[$i], \$Name)) { return 0; }
		
		if ("$Name" eq "$basic_params_ref->{5}->[0]") {
			if ( !getElementValue("Value", $RemedyFields[$i], \$basic_params_ref->{5}->[2]) ) { return 0; }
			
			$basic_params_ref->{5}->[3] = $basic_params_ref->{5}->[2]; # placeholder for a new value
			$bParamFound_1 = 1;
		}
		
		if ("$Name" eq "$basic_params_ref->{6}->[0]") {
			if ( !getElementValue("Value", $RemedyFields[$i], \$basic_params_ref->{6}->[2]) ) { return 0; }
			
			$basic_params_ref->{6}->[3] = $basic_params_ref->{6}->[2]; # placeholder for a new value
			$bParamFound_2 = 1;
		}
	}
	return ($bParamFound_1 && $bParamFound_2);
}

sub setRemedy7($$)
{
	my $basic_params_ref = shift;
	my $file_str_ref = shift;
	
	my $bParamFound_1 = 0;
	my $bParamFound_2 = 0;
	my @RemedyFields = getRemedyFields4Open($$file_str_ref);
	for (my $i = 0; $i < scalar(@RemedyFields); $i++)
	{
		my $Name = "";
		if ( !getElementValue("Name", $RemedyFields[$i], \$Name) ) { return 0; }
		if ("$Name" eq "$basic_params_ref->{5}->[0]") {
			if ( !setElementValue("Value", $basic_params_ref->{5}->[3], \$RemedyFields[$i]) ) { return 0; }
			$bParamFound_1 = 1;
		}
		if ("$Name" eq "$basic_params_ref->{6}->[0]") {
			if ( !setElementValue("Value", $basic_params_ref->{6}->[3], \$RemedyFields[$i]) ) { return 0; }
			$bParamFound_2 = 1;
		}
	}
	
	if ( $bParamFound_1 == 0 || $bParamFound_2 == 0 ) { return 0; }
	
	my $tmp = "";
	for (my $i=0; $i < scalar(@RemedyFields); $i++) {
		$tmp .= $RemedyFields[$i];
	}
	
	return setElementValue("RemedyFields", $tmp, $file_str_ref);
}

sub setRemedy7ForMigration($$)
{
	my $basic_params_ref = shift;
	my $file_str_ref = shift;
	
	my $bParamFound = 0;
	my $RemedyVersion = "7";
	
    my $tmp = "";

	if (!getAndSetRemedyFields4OpenMigration($file_str_ref, $basic_params_ref, $RemedyVersion))
    {
       return 0;
    }

    if (!getAndSetRemedyFields4CloseMigration($file_str_ref, $basic_params_ref, $RemedyVersion))
    {
       return 0;
    }

	return 1 ;
}

#-----------------------------------------------------
# Description:
#   Read an user-response from standard input, removes
#   new line characters and returns the value
#
# Input Params: N/A
# Output Params: the read value from standard input
#-----------------------------------------------------
sub ReadNewValue()
{
   my $new_value;

   $new_value = <STDIN>;

   print "\n";
   chomp $new_value;
   return $new_value;
}

sub GetRemedyConfFile()
{
	my $RemedyDataPath = common::GetRemedyDataPath();  
	my $RemedyConfigFileName = "RemedyConf.xml";
	my $RemedyConfXml = $RemedyDataPath . $RemedyConfigFileName;
    # for debugger my $RemedyConfXml = ".\\" . $RemedyConfigFileName;
	return $RemedyConfXml;
}

# read remedy parameters from exported config.dat file
sub handling_migration
{
    my %migration_params = ();
    
    # location of 613/620/630 exported config.dat

	my $MigrateDataPath = common::GetMigrateBackupDataPath();  
	my $MigrateConfigFileName = "export_config.dat";
	my $export_config = $MigrateDataPath . $MigrateConfigFileName;
	my $export_RemedyConfXML = $MigrateDataPath . "RemedyConf.xml";
        my $RemedyConfXml = GetRemedyConfFile();

    my $export_config_buf;
    my %export_config_hash;
        
sub read_hash;

    # sanity check for the existance of the exported config.dat file
    if (! -f $export_config) # '! -f' means 'not (exist) file'
    {
	   print ("Could not open the export_config.dat file",$export_config, " \n");
	   return 1;
    }

    # Starting 630 FP5 remedy parameters are defined on RemedyConf.xml file.
    # In case RemedyConf.xml exists on migrate_ctm/backup_ctm/data , copy this file to ctm_server/data/REMEDY
    if ( -f $export_RemedyConfXML)
    {
	   copy($export_RemedyConfXML, $RemedyConfXml);
	   return 0;
    }

    # read in the file exported 613/620/630 config.dat
	if (!read_hash($export_config, \%export_config_hash))
	{
	   print ("Cannot read file ",$export_config,"\n");
	   return 1;
    }
    # loop through exported 613/620/630 params
    my $key;
    my $found = 0;
	   
    foreach $key (sort keys %export_config_hash)
    {
       #connection settings parameter
       if (grep /\bREMEDY_SERVER_NAME\b/,$key)
       {
          $migration_params{$server_name} = ["ServerHostName", "Remedy Server Name", "", $export_config_hash{$key}];
          $found = 1;
       }
       elsif (grep /\bREMEDY_PORT_NUMBER\b/,$key)
       {
          $migration_params{$port_number} = ["Port", "Remedy Server Port", "", $export_config_hash{$key}];
          $found = 1;
       }
       elsif (grep /\bREMEDY_USER_NAME\b/,$key)
       {
          $migration_params{$user_name} = ["LoginUser", "User Name connect to remedy server", "", $export_config_hash{$key}];
          $found = 1;
       }
       #schema name for open remedy 6 or 7
       elsif (grep /\bREMEDY_SCHEMA\b/,$key)
       {
          $migration_params{$open_schema6} = ["SchemaName", "Parameter is the schema name for open in Remedy 6", "", $export_config_hash{$key}];
          $migration_params{$open_schema7} = ["SchemaName", "Parameter is the schema name for open in Remedy 7", "", $export_config_hash{$key}];
          $found = 1;
       }
       elsif (grep /\bREMEDY_REQUESTER_NAME\b/,$key)
       {
          $migration_params{$requester_name} = ["Name", "Requester name - for creating HelpDesk ticket in Remedy 6", "", $export_config_hash{$key}];
          $found = 1;
       }
       elsif (grep /\bREMEDY_OPEN_TICKET_STATUS\b/,$key)
       {
          my $open_ticket_status = "0"; # The default is NEW
          
          if ($export_config_hash{$key} eq "ASSIGNED")
          {   
             $open_ticket_status = "1";
          }
          elsif ($export_config_hash{$key} eq "WORK_IN_PROGRESS")
          {
             $open_ticket_status = "2";
          }
          elsif ($export_config_hash{$key} eq "PENDING")
          {     
             $open_ticket_status = "3";
          }   
             
 	      $migration_params{$open_status6} = ["Status", "Parameter is used to open ticket in Remedy 6", "", $open_ticket_status];
	      $migration_params{$open_status7} = ["Status", "Parameter is used to open ticket in Remedy 7", "", $open_ticket_status];	      
	      $found = 1;
       }
       elsif (grep /\bREMEDY_CATEGORY_NAME\b/,$key)
       {
          $migration_params{$category_name} = ["Category", "Parameter is used for create HelpDesk ticket in Remedy 6", "", $export_config_hash{$key}];
          $found = 1;
       }
       elsif (grep /\bREMEDY_TYPE\b/,$key)
       {
          $migration_params{$type} = ["type", "Parameter is used for create HelpDesk ticket in Remedy 6", "", $export_config_hash{$key}];
          $found = 1;
       }
       elsif (grep /\bREMEDY_ITEM\b/,$key)
       {
          $migration_params{$item} = ["Item", "Parameter is used for create HelpDesk ticket in Remedy 6", "", $export_config_hash{$key}];
          $found = 1;
       }
       elsif (grep /\bREMEDY_REQUESTER_LOGIN\b/,$key)
       {
          $migration_params{$requester_login} =  ["Login", "Requester login - used to create HelpDesk ticket in Remedy 6", "", $export_config_hash{$key}];
          $found = 1;
       }
       elsif (grep /\bREMEDY_CASE_SOURCE\b/,$key)
       {
          my $source = "1"; # The default is REQUESTER
          
          if ($export_config_hash{$key} eq "PHONE")
          {
             $source = "0";
          }
          elsif ($export_config_hash{$key} eq "EMAIL")
          {      
             $source = "2";
          }
          elsif ($export_config_hash{$key} eq "WEB")
          {      
             $source = "3";
          }   
          elsif ($export_config_hash{$key} eq "NMP")
          {      
             $source = "4";
          }   

          $migration_params{$case_source} = ["Source", "Parameter is used to create HelpDesk ticket in Remedy 6", "", $source];
          $found = 1;
       }
       elsif (grep /\bREMEDY_CASE_TYPE\b/,$key)
       {
          my $type = "0"; # The default is INCIDENT
          
          if ($export_config_hash{$key} eq "QUESTION")
          {
             $type = "1";
          }   
          elsif ($export_config_hash{$key} eq "REQUEST")
          {      
             $type = "2";
          }
          elsif ($export_config_hash{$key} eq "PROBLEM")      
          {
             $type = "3";
          }   

          $migration_params{$case_type} =  ["Case Type", "Parameter is used to create HelpDesk ticket in Remedy 6", "", $type];
          $found = 1;
       }
       #parameters for close remedy 6 or 7
       elsif (grep /\bREMEDY_CLOSE_SCHEMA\b/,$key)
       {
          $migration_params{$close_schema6} = ["SchemaName", "Parameter is the schema name for close in Remedy 6", "", $export_config_hash{$key}];
          $migration_params{$close_schema7} = ["SchemaName", "Parameter is the schema name for close in Remedy 7", "", $export_config_hash{$key}];
          $found = 1;          
       }
       elsif (grep /\bREMEDY_CLOSE_TICKET_STATUS\b/,$key)
       {
          my $close_ticket_status = "4"; # The default is RESOLVED
          
          if ($export_config_hash{$key} eq "CLOSED")
          {
             $close_ticket_status = "5";
          }

          $migration_params{$close_status6} = ["Status", "Parameter is used to close ticket in Remedy 6", "", $close_ticket_status];	   	   
          $migration_params{$close_status7} = ["Status", "Parameter is used to close ticket in Remedy 7", "", $close_ticket_status];	   	   
          $found = 1;
       }
       # schema name for open remedy 7 already covered in remedy 6 above

       # parameters for open remedy 7
       elsif (grep /\bREMEDY_FIRST_NAME\b/,$key)
       {
 	      $migration_params{$first_name} = ["FirstName", "Parameter is used to create ticket in Remedy 7", "", $export_config_hash{$key}];
          $found = 1;
	   }
       elsif (grep /\bREMEDY_LAST_NAME\b/,$key)
       {
	      $migration_params{$last_name} = ["LastName", "Parameter is used to create ticket in Remedy 7", "", $export_config_hash{$key}];
	      $found = 1;
	   }
       elsif (grep /\bREMEDY_IMPACT\b/,$key)
       {
          my $impact_val = "3000"; # The default is "M"
          
          if ($export_config_hash{$key} eq "E")
          {
             $impact_val = "1000";
          }
          elsif ($export_config_hash{$key} eq "S")
          {      
             $impact_val = "2000";
          }
          elsif ($export_config_hash{$key} eq "L")
          {      
             $impact_val = "4000";
          }   

	      $migration_params{$impact} = ["Impact", "Parameter is used to create ticket in Remedy 7", "", $impact_val];
	      $found = 1;
	   }
       elsif (grep /\bREMEDY_ACTION\b/,$key)
       {
          $migration_params{$action} = ["Action", "Parameter is used to create ticket in Remedy 7", "", $export_config_hash{$key}];
          $found = 1;
	   }
       #parameters for close remedy 7
       elsif (grep /\bREMEDY_ASSIGNEE\b/,$key)
       {
          $migration_params{$assignee} = ["Assignee", "Parameter is used to close incident ticket in Remedy 7", "", $export_config_hash{$key}];	   	   
          $found = 1;
       }
       elsif (grep /\bREMEDY_ASSIGNEE_LOGIN_ID\b/,$key)
       {
          $migration_params{$assignee_login_id} = ["Assignee Login ID", "Parameter is used to close incident ticket in Remedy 7", "", $export_config_hash{$key}];	   	   
          $found = 1;
       }
	}

    if ($found == 1)
    {
       my $rc = SaveConfiguration(\%migration_params);
    
       if ( $rc <= 0) #Because SaveConfiguration function returns 0 if it ends NOT OK
       {   
          return 1;
       }   
    }
    
    return 0; 
}

# read file into hash, and buffer if it is passed
sub read_hash
{
	my $filename = shift;  # arg 1
	my $hashref = shift;   # arg 2

	my $buf; # use this buffer if none is passed
	# 3rd arg (reference to buffer) is optional
	my $bufref = shift || \$buf;

	# $bufref is now a reference to some buffer, either $buf or what was passed to the subroutine

	if (!open(FILE, $filename))
	{
		print "Cannot open file: $filename ($!)\n";
		return 0;
	}

	my $line;
	while (<FILE>)
	{
		# special variable '$_' contains the line

		my $key;
            my $value;
		
		# append line to buffer.  The first '$' de-references the reference variable $bufref
		$$bufref .= $_;

		# get rid of cr/lf from $_
		chomp;
		
		# skip comments and empty lines
		next if /^!/ || /^#/ || /^\s*$/;

		# extract key/value
		($key, $value) = (/^([^\s]*)\s*(.*)$/);
		# print "key=($key) value=($value)\n";
		
		# put the paramter in the hash
		$hashref->{$key} = $value;
	}
	close FILE;
	# success
	return 1;
}
